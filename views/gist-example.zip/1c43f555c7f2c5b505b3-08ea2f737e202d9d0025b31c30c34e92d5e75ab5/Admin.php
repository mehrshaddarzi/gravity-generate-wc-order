<?php

/**
 * Title: WordPress pay extension Gravity Forms admin
 * Description:
 * Copyright: Copyright (c) 2005 - 2015
 * Company: Pronamic
 * @author Remco Tolsma
 * @version 1.1.0
 */
class Pronamic_WP_Pay_Extensions_GravityForms_Admin {
	/**
	 * Bootstrap
	 */
	public static function bootstrap() {
		// Actions
		add_action( 'admin_init',               array( __CLASS__, 'admin_init' ) );
		add_action( 'admin_init',               array( __CLASS__, 'maybe_redirect_to_entry' ) );

		add_action( 'gform_form_settings_page_pronamic_pay_gf', array( __CLASS__, 'form_settings_page' ) );

		// Filters
		add_filter( 'gform_addon_navigation',   array( __CLASS__, 'addon_navigation' ) );
		add_filter( 'gform_form_settings_menu', array( __CLASS__, 'form_settings_menu_item' ) );

		add_filter( 'gform_entry_info',         array( __CLASS__, 'entry_info' ), 10, 2 );

		add_filter( 'gform_custom_merge_tags',  array( __CLASS__, 'custom_merge_tags' ), 10 );

		// Actions - AJAX
		add_action( 'wp_ajax_gf_get_form_data', array( __CLASS__, 'ajax_get_form_data' ) );
	}

	//////////////////////////////////////////////////

	/**
	 * Admin initialize
	 */
	public static function admin_init() {
		new Pronamic_WP_Pay_Extensions_GravityForms_AdminPaymentFormPostType();
	}

	//////////////////////////////////////////////////

	/**
	 * Gravity Forms addon navigation
	 *
	 * @param $menus array with addon menu items
	 * @return array
	 */
	public static function addon_navigation( $menus ) {
		if ( version_compare( GFCommon::$version, '1.7', '<' ) ) {
			$menus[] = array(
				'name'       => 'edit.php?post_type=pronamic_pay_gf',
				'label'      => __( 'iDEAL', 'pronamic_ideal' ),
				'callback'   => null,
				'permission' => 'manage_options',
			);
		}

		return $menus;
	}

	//////////////////////////////////////////////////

	/**
	 * Add menu item to form settings
	 *
	 * @param $menu_items array with form settings menu items
	 * @return array
	 */
	public static function form_settings_menu_item( $menu_items ) {
		$menu_items[] = array(
			'name' => 'pronamic_pay_gf',
			'label' => __( 'iDEAL', 'pronamic-ideal' ),
		);

		return $menu_items;
	}

	//////////////////////////////////////////////////

	/**
	 * Handle payment form settings
	 */
	public static function form_settings_page() {
		if ( filter_has_var( INPUT_POST, 'pronamic_pay_nonce' ) ) {
			$nonce = filter_input( INPUT_POST, 'pronamic_pay_nonce', FILTER_SANITIZE_STRING );

			// Verify that the nonce is valid.
			if ( wp_verify_nonce( $nonce, 'pronamic_pay_save_pay_gf' ) ) {
				global $wpdb;

				$form_id = filter_input( INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT );

				$query = new WP_Query( array(
					'post_type'			=> 'pronamic_pay_gf',
					'posts_per_page'	=> 1,
					'meta_query'		=> array(
						'key'			=> '_pronamic_pay_gf_form_id',
						'value'			=> $form_id,
					),
				) );

				$post_id = $query->posts[0]->ID;

				if ( ! $post_id ) {
					wp_insert_post( array(
						'post_type'			=> 'pronamic_pay_gf',
						'post_name'			=> 'pronamic-pay-gf-' . $form_id,
						'post_title'		=> 'Pronamic iDEAL for Gravity Forms #' . $form_id,
						'post_status'		=> 'publish',
						'comment_status'	=> 'closed',
						'ping_status'		=> 'closed',
					) );

					$post_id = $wpdb->insert_id;
				}

				wp_update_post( array(
					'ID' => $post_id,
				) );
			}
		}

		GFFormSettings::page_header();

		require( dirname( __FILE__ ) . '/../views/html-admin-meta-box-config.php' );

		GFFormSettings::page_footer();
	}

	//////////////////////////////////////////////////

	/**
	 * Render entry info of the specified form and lead
	 *
	 * @param string $form_id
	 * @param array $lead
	 */
	public static function entry_info( $form_id, $lead ) {
		$payment_id = gform_get_meta( $lead['id'], 'pronamic_payment_id' );

		if ( $payment_id ) {
			printf(
				'<a href="%s">%s</a>',
				get_edit_post_link( $payment_id ),
				get_the_title( $payment_id )
			);
		}
	}

	//////////////////////////////////////////////////

	/**
	 * Custom merge tags
	 */
	public static function custom_merge_tags( $merge_tags ) {
		$merge_tags[] = array(
			'label' => __( 'Payment Status', 'pronamic_ideal' ),
			'tag'   => '{payment_status}',
		);

		$merge_tags[] = array(
			'label' => __( 'Payment Date', 'pronamic_ideal' ),
			'tag'   => '{payment_date}',
		);

		$merge_tags[] = array(
			'label' => __( 'Transaction Id', 'pronamic_ideal' ),
			'tag'   => '{transaction_id}',
		);

		$merge_tags[] = array(
			'label' => __( 'Payment Amount', 'pronamic_ideal' ),
			'tag'   => '{payment_amount}',
		);

		return $merge_tags;
	}

	//////////////////////////////////////////////////

	/**
	 * Maybed redirect to Gravity Forms entry
	 */
	public static function maybe_redirect_to_entry() {
		if ( filter_has_var( INPUT_GET, 'pronamic_gf_lid' ) ) {
			$lead_id = filter_input( INPUT_GET, 'pronamic_gf_lid', FILTER_SANITIZE_STRING );

			$lead = RGFormsModel::get_lead( $lead_id );

			if ( ! empty( $lead ) ) {
				$url = add_query_arg( array(
					'page' => 'gf_entries',
					'view' => 'entry',
					'id'   => $lead['form_id'],
					'lid'  => $lead_id,
				), admin_url( 'admin.php' ) );

				wp_redirect( $url, 303 );

				exit;
			}
		}
	}

	//////////////////////////////////////////////////

	/**
	 * Handle AJAX request get form data
	 */
	public static function ajax_get_form_data() {
		$form_id = filter_input( INPUT_GET, 'formId', FILTER_SANITIZE_STRING );

		$result = new stdClass();
		$result->success = true;
		$result->data    = RGFormsModel::get_form_meta( $form_id );

		// Output
		header( 'Content-Type: application/json' );

		echo json_encode( $result );

		die();
	}
}
